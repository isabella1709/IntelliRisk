from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()
instance = "mysql+pymysql://root:%401234@localhost:3306/dengue"